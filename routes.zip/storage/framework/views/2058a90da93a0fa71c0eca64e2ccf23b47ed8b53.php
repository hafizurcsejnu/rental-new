<div class="post_item ">
        <div class="header">
            <header class="post-header">
            <a href="/news-detail/<?php echo e($post->slug); ?>">
                    <img class="lazy loaded" data-src="<?php echo e(Voyager::image($post->image)); ?>" alt="" src="<?php echo e(Voyager::image($post->image)); ?>" data-was-processed="true">
                </a>
            </header>
            <div class="cate">
                <ul>
                    
                </ul>
            </div>
            <div class="post-inner">
                <h4 class="post-title">
                <a class="text-darken" href="/news-detail/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a>
</h4>
                <div class="post-info">
                    <ul>
                        <li>
                            <span class="avatar-text">S</span>
                            <span> BY </span> <?php echo e($post->author->name); ?>

                        </li>
                        <li> DATE: <?php echo e($post->created_at->format('F d, Y')); ?> </li>
                    </ul>
                </div>
                <div class="post-desciption">
                    <?php echo e($post->excerpt); ?>

                </div>
                <a class="btn-readmore" href="/news-detail/<?php echo e($post->slug); ?>">Read More</a>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\rental\resources\views/partials/news_post.blade.php ENDPATH**/ ?>