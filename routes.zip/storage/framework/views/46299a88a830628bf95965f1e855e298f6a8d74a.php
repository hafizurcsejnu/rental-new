<?php $__env->startSection('content'); ?>



    <div class="blog-breadcrumb hidden-xs">
        <div class="container">
            <ul>
                <li><a href="<?php echo e(url('/')); ?>"> Home</a></li>
                <li class="active">
                    <a href="<?php echo e(url('/')); ?>/news">News</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="bravo_content">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="list-news">
                       
                   
                          
                      <div class="article">
                        <div class="header">
                            <header class="post-header">
                                <img src="<?php echo e(Voyager::image($data->image)); ?>" alt="<?php echo e($data->title); ?>">
                            </header>
                            <div class="cate">
                                <ul>
                                    
                                </ul>
                            </div>
                        </div>
                    <h2 class="title"><?php echo e($data->title); ?></h2>
                        <div class="post-info">
                            <ul>
                                <li>
                                    <span> BY </span> <?php echo e($data->author->name); ?>

                                </li>
                                <li> DATE: <?php echo e($data->created_at->format('F d, Y')); ?> </li>
                            </ul>
                        </div>
                        <div class="post-content"><?php echo $data->body; ?></div>

                        <div class="space-between">
                            <div class="share"> Share
                                <a class="facebook share-item" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url('/')); ?>/en/news/morning-in-the-northern-sea&amp;title=Morning in the Northern sea" target="_blank" original-title="Facebook"><i class="fa fa-facebook fa-lg"></i></a>
                                <a class="twitter share-item" href="https://twitter.com/share?url=<?php echo e(url('/')); ?>/en/news/morning-in-the-northern-sea&amp;title=Morning in the Northern sea" target="_blank" original-title="Twitter"><i class="fa fa-twitter fa-lg"></i></a>
                            </div>
                        </div>
                    </div>
                              
                    <hr>

                        <div class="bravo-pagination">

                            
                           
                            
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <?php echo $__env->make('partials.news_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rental\resources\views/pages/news_details.blade.php ENDPATH**/ ?>