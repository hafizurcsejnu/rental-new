<?php $__env->startSection('content'); ?>



    <div class="blog-breadcrumb hidden-xs">
        <div class="container">
            <ul>
                <li><a href="<?php echo e(url('/')); ?>"> Home</a></li>
                <li class="active">
                    <a href="<?php echo e(url('/')); ?>/news">News</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="bravo_content">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="list-news">
                       
                      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo $__env->make('partials.news_post', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                    <hr>

                        <div class="bravo-pagination">

                            
                           
                            
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <?php echo $__env->make('partials.news_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rental\resources\views/pages/news.blade.php ENDPATH**/ ?>